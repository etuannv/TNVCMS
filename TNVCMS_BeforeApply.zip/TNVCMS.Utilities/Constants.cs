﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TNVCMS.Utilities
{
    public class Constants
    {
        public const string TAXONOMY_CATEGORY = "category";
        public const string TAXONOMY_TAG = "tag";

        public const string NEWS_STATUS_DRAFT = "DRAFT";
        public const string NEWS_STATUS_PEDDING = "PEDDING";
        public const string NEWS_STATUS_PUBLIC = "PUBLISHED";
        
    }
}
